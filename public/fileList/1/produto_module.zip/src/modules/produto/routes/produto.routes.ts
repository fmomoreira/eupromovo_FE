
import { Router } from "express";
import ProdutoController from "../controller/ProdutoController";
import { Joi, Segments, celebrate } from "celebrate";

const produtoRouter = Router();
const controller = new ProdutoController();

produtoRouter.get('/', controller.index);

produtoRouter.post(
    '/',
    celebrate({
        [Segments.BODY]: Joi.object().keys({
            descricao: Joi.string().required(),
            codBarras: Joi.string().optional(),
            precoCusto: Joi.number().required(),
            precoVenda: Joi.number().required(),
            fabricante: Joi.string().optional(),
        }),
    }),
    controller.create
);

produtoRouter.get(
    '/:id',
    celebrate({
        [Segments.PARAMS]: Joi.object().keys({
            id: Joi.number().integer().required(),
        }),
    }),
    controller.show
);

produtoRouter.put(
    '/:id',
    celebrate({
        [Segments.PARAMS]: Joi.object().keys({
            id: Joi.number().integer().required(),
        }),
        [Segments.BODY]: Joi.object().keys({
            descricao: Joi.string().optional(),
            codBarras: Joi.string().optional(),
            precoCusto: Joi.number().optional(),
            precoVenda: Joi.number().optional(),
            fabricante: Joi.string().optional(),
        }),
    }),
    controller.update
);

produtoRouter.delete(
    '/:id',
    celebrate({
        [Segments.PARAMS]: Joi.object().keys({
            id: Joi.number().integer().required(),
        }),
    }),
    controller.delete
);

export default produtoRouter;
