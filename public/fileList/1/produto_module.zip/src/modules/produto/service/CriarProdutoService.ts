
import { prisma } from "@database/prisma";
import { AppError } from "@shared/AppError/AppError";
import { Produto } from "@prisma/client";

interface ICriarProdutoDTO {
    descricao: string;
    codBarras?: string;
    precoCusto: number;
    precoVenda: number;
    fabricante?: string;
}

export default class CriarProdutoService {
    public async execute(data: ICriarProdutoDTO): Promise<Produto> {
        const produtoExistente = await prisma.produto.findUnique({
            where: { codBarras: data.codBarras },
        });

        if (produtoExistente) {
            throw new AppError("Produto já cadastrado com este código de barras", 400);
        }

        const produto = await prisma.produto.create({
            data,
        });

        return produto;
    }
}
