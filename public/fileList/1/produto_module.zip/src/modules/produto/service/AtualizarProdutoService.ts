
import { prisma } from "@database/prisma";
import { AppError } from "@shared/AppError/AppError";
import { Produto } from "@prisma/client";

interface IAtualizarProdutoDTO {
    descricao?: string;
    codBarras?: string;
    precoCusto?: number;
    precoVenda?: number;
    fabricante?: string;
}

export default class AtualizarProdutoService {
    public async execute(id: number, data: IAtualizarProdutoDTO): Promise<Produto> {
        const produtoExistente = await prisma.produto.findUnique({ where: { id } });

        if (!produtoExistente) {
            throw new AppError("Produto não encontrado", 404);
        }

        const produto = await prisma.produto.update({
            where: { id },
            data,
        });

        return produto;
    }
}
