
import { prisma } from "@database/prisma";
import { Produto } from "@prisma/client";

export default class ListarTodosProdutosService {
    public async execute(): Promise<Produto[]> {
        return await prisma.produto.findMany();
    }
}
