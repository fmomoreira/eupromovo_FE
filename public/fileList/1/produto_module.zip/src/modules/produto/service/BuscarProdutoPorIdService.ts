
import { prisma } from "@database/prisma";
import { AppError } from "@shared/AppError/AppError";
import { Produto } from "@prisma/client";

export default class BuscarProdutoPorIdService {
    public async execute(id: number): Promise<Produto | null> {
        const produto = await prisma.produto.findUnique({
            where: { id },
        });

        if (!produto) {
            throw new AppError("Produto não encontrado", 404);
        }

        return produto;
    }
}
