
import { prisma } from "@database/prisma";
import { AppError } from "@shared/AppError/AppError";

export default class DeletarProdutoService {
    public async execute(id: number): Promise<void> {
        const produtoExistente = await prisma.produto.findUnique({ where: { id } });

        if (!produtoExistente) {
            throw new AppError("Produto não encontrado", 404);
        }

        await prisma.produto.delete({
            where: { id },
        });
    }
}
