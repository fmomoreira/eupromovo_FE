
import { Request, Response } from "express";
import ListarTodosProdutosService from "../service/ListarTodosProdutosService";
import CriarProdutoService from "../service/CriarProdutoService";
import BuscarProdutoPorIdService from "../service/BuscarProdutoPorIdService";
import AtualizarProdutoService from "../service/AtualizarProdutoService";
import DeletarProdutoService from "../service/DeletarProdutoService";

export default class ProdutoController {
    public async index(req: Request, res: Response): Promise<any> {
        const listarProdutos = new ListarTodosProdutosService();
        const produtos = await listarProdutos.execute();
        return res.status(200).json(produtos);
    }

    public async create(req: Request, res: Response): Promise<any> {
        const data = req.body;
        const criarProdutoService = new CriarProdutoService();
        const produto = await criarProdutoService.execute(data);
        return res.status(201).json(produto);
    }

    public async show(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        const buscarProdutoPorId = new BuscarProdutoPorIdService();
        const produto = await buscarProdutoPorId.execute(Number(id));
        return res.status(200).json(produto);
    }

    public async update(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        const data = req.body;
        const atualizarProdutoService = new AtualizarProdutoService();
        const produto = await atualizarProdutoService.execute(Number(id), data);
        return res.status(200).json(produto);
    }

    public async delete(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        const deletarProdutoService = new DeletarProdutoService();
        await deletarProdutoService.execute(Number(id));
        return res.status(200).json({ message: "Produto deletado com sucesso" });
    }
}
